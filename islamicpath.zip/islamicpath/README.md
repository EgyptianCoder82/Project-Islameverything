# IslamicPath

A Pen created on CodePen.

Original URL: [https://codepen.io/SimpleCoder82/pen/xbRmGWg](https://codepen.io/SimpleCoder82/pen/xbRmGWg).

